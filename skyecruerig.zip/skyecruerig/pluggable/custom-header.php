<?php
/**
 * Custom Header feature
 *
 * @link https://developer.wordpress.org/themes/functionality/custom-headers/
 *
 * @package skyecruerig
 */

/**
 * Set up the WordPress core custom header feature.
 *
 * @uses skyecruerig_header_style()
 */
function skyecruerig_custom_header_setup() {
	add_theme_support(
		'custom-header', apply_filters(
			'skyecruerig_custom_header_args', array(
				'default-image'          => '',
				'default-text-color'     => '000000',
				'width'                  => 1600,
				'height'                 => 250,
				'flex-height'            => true,
				'wp-head-callback'       => 'skyecruerig_header_style',
			)
		)
	);
}
add_action( 'after_setup_theme', 'skyecruerig_custom_header_setup' );


	
