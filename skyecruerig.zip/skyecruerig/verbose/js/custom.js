"use strict";

var custom = void 0;

function doSomeMath() {
	custom++;
	return custom;
}

doSomeMath();