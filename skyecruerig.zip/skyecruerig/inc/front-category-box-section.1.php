<div class="flexbox-7">

		<div class="featured-box">
            <a href="<?php if( get_theme_mod('category1_link', '#') != '' ){ echo esc_url( get_theme_mod('category1_link') ); } ?>">
                <?php if( get_theme_mod('category1_icon') != '' ) { ?>
                <div class="featured-box-image"><img src="<?php  echo esc_url( get_theme_mod('category1_icon') ); ?>" alt="boximg"/></div>
                <?php } else { ?> <span class="font-icon-first skin-bg"></span> <?php  } ?>
                <div class="featured-box-heading"><?php if( get_theme_mod('category1_heading', '') != '' ) { echo esc_attr( get_theme_mod('category1_heading') ); } else { ?><?php _e('creative','skyecruerig'); } ?></div>
            </a>
         </div><!-- .featured-box -->

         <div class="featured-box">
            <a href="<?php if( get_theme_mod('category2_link', '#') != '' ){ echo esc_url( get_theme_mod('category2_link') ); } ?>">
                <?php if( get_theme_mod('category2_icon') != '' ) { ?>
                <div class="featured-box-image"><img src="<?php  echo esc_url( get_theme_mod('category2_icon') ); ?>" alt="boximg"/></div>
                <?php } else { ?> <span class="font-icon-first skin-bg"></span> <?php  } ?>
                <div class="featured-box-heading"><?php if( get_theme_mod('category2_heading', '') != '' ) { echo esc_attr( get_theme_mod('category2_heading') ); } else { ?><?php _e('creative','skyecruerig'); } ?></div>
            </a>
         </div><!-- .featured-box -->

         <div class="featured-box">
            <a href="<?php if( get_theme_mod('category3_link', '#') != '' ){ echo esc_url( get_theme_mod('category3_link') ); } ?>">
                <?php if( get_theme_mod('category3_icon') != '' ) { ?>
                <div class="featured-box-image"><img src="<?php  echo esc_url( get_theme_mod('category3_icon') ); ?>" alt="boximg"/></div>
                <?php } else { ?> <span class="font-icon-first skin-bg"></span> <?php  } ?>
                <div class="featured-box-heading"><?php if( get_theme_mod('category3_heading', '') != '' ) { echo esc_attr( get_theme_mod('category1_heading') ); } else { ?><?php _e('creative','skyecruerig'); } ?></div>
            </a>
         </div><!-- .featured-box -->

         <div class="featured-box">
            <a href="<?php if( get_theme_mod('category4_link', '#') != '' ){ echo esc_url( get_theme_mod('category4_link') ); } ?>">
                <?php if( get_theme_mod('category4_icon') != '' ) { ?>
                <div class="featured-box-image"><img src="<?php  echo esc_url( get_theme_mod('category4_icon') ); ?>" alt="boximg"/></div>
                <?php } else { ?> <span class="font-icon-first skin-bg"></span> <?php  } ?>
                <div class="featured-box-heading"><?php if( get_theme_mod('category4_heading', '') != '' ) { echo esc_attr( get_theme_mod('category2_heading') ); } else { ?><?php _e('creative','skyecruerig'); } ?></div>
            </a>
         </div><!-- .featured-box -->

         <div class="featured-box">
            <a href="<?php if( get_theme_mod('category5_link', '#') != '' ){ echo esc_url( get_theme_mod('category5_link') ); } ?>">
                <?php if( get_theme_mod('category2_icon') != '' ) { ?>
                <div class="featured-box-image"><img src="<?php  echo esc_url( get_theme_mod('category5_icon') ); ?>" alt="boximg"/></div>
                <?php } else { ?> <span class="font-icon-first skin-bg"></span> <?php  } ?>
                <div class="featured-box-heading"><?php if( get_theme_mod('category5_heading', '') != '' ) { echo esc_attr( get_theme_mod('category5_heading') ); } else { ?><?php _e('creative','skyecruerig'); } ?></div>
            </a>
         </div><!-- .featured-box -->

