<div class="flexbox-7">

		<div class="featured-box">
                 <div class="featured-box-heading"><?php if( get_theme_mod('category1_heading', '') != '' ) { echo esc_attr( get_theme_mod('category1_heading') ); } else { ?><?php _e('','skyecruerig'); } ?></div>
        </div><!-- .featured-box -->
