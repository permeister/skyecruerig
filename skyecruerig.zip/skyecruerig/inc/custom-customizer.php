<?php

function skyecruerig_customize_register( $wp_customize) {
//All our sections, settings, and controls will be added here
}


$wp_customize->add_setting('header_bg_color', array(
	'default'	=> '#4285f4',
	'transport'	=> 'refresh',
));

$wp_customize->add_section( 'skyecruerig_color_theme_section', array(
	'title'		=> __('Color', 'skyecruerig'),
	'priority'	=> 30,
));

$wp_customize->add_control(new WP_Customize_Color_Control( $wp_customize, 'theme_color', array(
	'label'		=>__('Header Color', 'skyecruerig'),
	'section'	=> 'skyecruerig_color_theme_section',
	'settings'	=> 'header_bg_color',
)));

add_action( 'customize_register', 'skyecruerig_customize_register');
